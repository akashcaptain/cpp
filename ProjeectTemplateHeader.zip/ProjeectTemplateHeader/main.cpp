#include <iostream>
#include "template.cpp" // include template.cpp in main program 
// #include "template.h" // for header file 
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
/*In general, it is bad practice to include another .cpp file inside of a .cpp file. The right way is to break out declarations into .h files 
and put the definitions in .cpp files. 
Make sure to put a bogus define at the top of each of your .h files to prevent accidental re-inclusion, as in:
*/
int main(){
 	calc<int> c; // declearation 
 	cout << c.multiply(12,34);
 	return 0;
 }
